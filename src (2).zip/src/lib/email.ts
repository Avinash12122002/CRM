import nodemailer from "nodemailer";
import { connectToDatabase } from "./mongodb";
import { ObjectId } from "mongodb";

// ─────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────

export type EmailStage =
  | "info"
  | "agreement"
  | "invoice"
  | "payment_confirmation"
  | "case_manager";

export const STAGE_ORDER: EmailStage[] = [
  "info",
  "agreement",
  "invoice",
  "payment_confirmation",
  "case_manager",
];

export const STAGE_LABELS: Record<EmailStage, string> = {
  info: "Information",
  agreement: "Agreement",
  invoice: "Invoice",
  payment_confirmation: "Payment Confirmation",
  case_manager: "Case Manager Intro",
};

export const STAGE_MAILBOXES: Record<EmailStage, string> = {
  info: "info@tmsvisa.com",
  agreement: "compliance@tmsvisa.com",
  invoice: "sales@tmsvisa.com",
  payment_confirmation: "sales@tmsvisa.com",
  case_manager: "sumit.recruiter@tmsvisa.com",
};

// ─────────────────────────────────────────────
// SMTP Transport (per-mailbox)
// ─────────────────────────────────────────────

export function createTransport(mailboxEmail?: string) {
  // Use env vars; can be extended to per-mailbox SMTP in future
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST || "smtp.gmail.com",
    port: parseInt(process.env.SMTP_PORT || "587"),
    secure: process.env.SMTP_SECURE === "true",
    auth: {
      user: process.env.SMTP_USER || mailboxEmail,
      pass: process.env.SMTP_PASS,
    },
  });
}

// ─────────────────────────────────────────────
// Template Variable Replacement
// ─────────────────────────────────────────────

export function replaceTemplateVars(
  template: string,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  vars: Record<string, any>
): string {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => {
    return vars[key] !== undefined ? String(vars[key]) : `{{${key}}}`;
  });
}

// ─────────────────────────────────────────────
// Send Email
// ─────────────────────────────────────────────

export interface SendEmailOptions {
  from: string;
  fromName?: string;
  to: string;
  subject: string;
  html: string;
  attachments?: { filename: string; content: Buffer; contentType: string }[];
}

export async function sendEmail(options: SendEmailOptions) {
  const smtpHost = process.env.SMTP_HOST;
  const smtpPass = process.env.SMTP_PASS;

  // Simulate if SMTP not configured or still using placeholder
  const isPlaceholder =
    !smtpHost ||
    !smtpPass ||
    smtpPass === "your_smtp_password_here" ||
    smtpPass === "";

  if (isPlaceholder) {
    console.log("[Email] SMTP not configured — simulating send:", {
      from: options.from,
      to: options.to,
      subject: options.subject,
    });
    return { success: true, simulated: true };
  }

  try {
    const transporter = createTransport(options.from);
    await transporter.sendMail({
      from: options.fromName
        ? `"${options.fromName}" <${options.from}>`
        : options.from,
      to: options.to,
      subject: options.subject,
      html: options.html,
      attachments: options.attachments,
    });
    return { success: true, simulated: false };
  } catch (err) {
    // Log the error but don't crash — return simulated so workflow still advances
    console.error("[Email] SMTP send failed (falling back to simulated):", err);
    return { success: false, simulated: true, error: String(err) };
  }
}

// ─────────────────────────────────────────────
// Lead Workflow Helpers
// ─────────────────────────────────────────────

export async function getLeadWorkflow(leadId: number) {
  const { db } = await connectToDatabase();
  return db.collection("lead_workflows").findOne({ leadId });
}

export async function createOrGetLeadWorkflow(leadId: number) {
  const { db } = await connectToDatabase();
  const existing = await db.collection("lead_workflows").findOne({ leadId });
  if (existing) return existing;

  const doc = {
    leadId,
    currentStage: null as EmailStage | null,
    workflowId: null,
    workflowName: null,
    followupCount: 0,
    nextFollowupAt: null,
    lastEmailAt: null,
    stageStartedAt: null,
    isCompleted: false,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  await db.collection("lead_workflows").insertOne(doc);
  return doc;
}

export async function advanceLeadStage(
  leadId: number,
  newStage: EmailStage,
  workflowName?: string
) {
  const { db } = await connectToDatabase();

  const followupDays = 3;
  const nextFollowupAt = new Date();
  nextFollowupAt.setDate(nextFollowupAt.getDate() + followupDays);

  // Cancel any pending followups for previous stage
  await db.collection("email_history").updateMany(
    { leadId, isPendingFollowup: true, cancelled: { $ne: true } },
    { $set: { cancelled: true, cancelledAt: new Date() } }
  );

  await db.collection("lead_workflows").updateOne(
    { leadId },
    {
      $set: {
        currentStage: newStage,
        workflowName: workflowName || null,
        followupCount: 0,
        nextFollowupAt,
        stageStartedAt: new Date(),
        updatedAt: new Date(),
      },
      $setOnInsert: { leadId, createdAt: new Date() },
    },
    { upsert: true }
  );
}

export async function scheduleNextFollowup(leadId: number, daysFromNow = 3) {
  const { db } = await connectToDatabase();
  const nextFollowupAt = new Date();
  nextFollowupAt.setDate(nextFollowupAt.getDate() + daysFromNow);

  await db.collection("lead_workflows").updateOne(
    { leadId },
    {
      $set: { nextFollowupAt, updatedAt: new Date() },
      $inc: { followupCount: 1 },
    }
  );
}

// ─────────────────────────────────────────────
// Record Email in History
// ─────────────────────────────────────────────

export interface EmailHistoryRecord {
  leadId: number;
  leadName: string;
  stage: EmailStage;
  mailbox: string;
  templateId?: string;
  templateName: string;
  subject: string;
  bodyPreview: string;
  status: "sent" | "failed" | "simulated";
  isFollowup: boolean;
  followupNumber: number;
  isPendingFollowup: boolean;
  cancelled: boolean;
  sentAt: Date;
  sentBy: number;
  sentByName: string;
  invoiceId?: string;
}

export async function recordEmailHistory(record: EmailHistoryRecord) {
  const { db } = await connectToDatabase();
  const result = await db.collection("email_history").insertOne({
    ...record,
    _id: new ObjectId(),
    createdAt: new Date(),
  });
  return result;
}

// ─────────────────────────────────────────────
// Cron: Process Due Follow-ups
// ─────────────────────────────────────────────

export async function processDueFollowups() {
  const { db } = await connectToDatabase();
  const now = new Date();

  // Find all lead workflows with a due follow-up
  const dueWorkflows = await db
    .collection("lead_workflows")
    .find({
      nextFollowupAt: { $lte: now },
      currentStage: { $ne: null },
      isCompleted: false,
    })
    .toArray();

  const results = [];

  for (const wf of dueWorkflows) {
    try {
      // Get the lead info
      const lead = await db.collection("leads").findOne({ id: wf.leadId });
      if (!lead) continue;

      const stage = wf.currentStage as EmailStage;
      const mailbox = STAGE_MAILBOXES[stage];
      const followupNum = (wf.followupCount || 0) + 1;
      const stageLabel = STAGE_LABELS[stage];

      const subject = `Follow-up ${followupNum}: ${stageLabel} — ${lead.name}`;
      const html = `
        <p>Dear ${lead.name},</p>
        <p>This is a follow-up regarding your <strong>${stageLabel}</strong>.</p>
        <p>Please let us know if you have any questions or are ready to proceed.</p>
        <p>Regards,<br/>TMS Visa Team</p>
      `;

      const sendResult = await sendEmail({
        from: mailbox,
        fromName: "TMS Visa",
        to: lead.email,
        subject,
        html,
      });

      // Record in history
      await recordEmailHistory({
        leadId: wf.leadId,
        leadName: lead.name,
        stage,
        mailbox,
        templateName: `Auto Follow-up ${followupNum}`,
        subject,
        bodyPreview: `Follow-up ${followupNum} for ${stageLabel}`,
        status: sendResult.simulated ? "simulated" : "sent",
        isFollowup: true,
        followupNumber: followupNum,
        isPendingFollowup: false,
        cancelled: false,
        sentAt: new Date(),
        sentBy: 0,
        sentByName: "System",
      });

      // Schedule next follow-up
      await scheduleNextFollowup(wf.leadId, 3);

      results.push({ leadId: wf.leadId, success: true, followupNum });
    } catch (err) {
      results.push({ leadId: wf.leadId, success: false, error: String(err) });
    }
  }

  return results;
}
