import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import { verifyToken } from "@/lib/auth";
import { logUserAction } from "@/lib/activity/audit";

export async function PUT(
  req: NextRequest,
  context: { params: Promise<{ id: string }> },
) {
  try {
    const cookie = req.headers.get("cookie") || "";
    const matches = cookie.match(/(^|; )token=([^;]+)/);
    const token = matches ? matches[2] : null;

    if (!token) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
    }

    const payload = verifyToken(token);
    if (!payload) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
    }

    if (payload.role === "case_manager" || payload.role === "wcm") {
      return NextResponse.json({ message: "Forbidden" }, { status: 403 });
    }

    const { id } = await context.params;
    const leadId = parseInt(id);

    if (isNaN(leadId)) {
      return NextResponse.json({ message: "Invalid lead ID" }, { status: 400 });
    }

    const body = await req.json();
    const {
      name,
      phone,
      email,
      dueDate,
      callbackDate,
      state,
      city,
      country,
      age,
      status,
      passportType,
      leadSource,
      jobApplied,
      interestedCountry,
    } = body;

    if (!phone?.trim()) {
      return NextResponse.json(
        { message: "Phone is required" },
        { status: 400 },
      );
    }

    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email).trim())) {
      return NextResponse.json(
        { message: "Please enter a valid email address" },
        { status: 400 },
      );
    }

    const cleanInterestedCountry =
      typeof interestedCountry === "string" ? interestedCountry.trim() : "";

    if (cleanInterestedCountry && !["Australia", "Ireland"].includes(cleanInterestedCountry)) {
      return NextResponse.json(
        { message: "Invalid interested country. Must be Australia or Ireland." },
        { status: 400 },
      );
    }

    const { db } = await connectToDatabase();

    // Find the lead
    const lead = await db.collection("leads").findOne({ id: leadId });

    if (!lead) {
      return NextResponse.json({ message: "Lead not found" }, { status: 404 });
    }

    // Check permissions: Admins can edit any lead, telecallers can only edit leads assigned to them
    if (payload.role === "follow_up") {
      const isCompleted =
        lead.followUpWorkflow?.currentStage === "completed" ||
        lead.followUpWorkflow?.status === "completed" ||
        !!lead.followUpWorkflow?.stages?.case_manager;
      if (isCompleted) {
        return NextResponse.json(
          { message: "This lead is read-only as the follow-up process is completed." },
          { status: 403 },
        );
      }
    }

    if (
      (payload.role === "telecaller" ||
        payload.role === "employee" ||
        payload.role === "meeting" ||
        payload.role === "wtc" ||
        payload.role === "wm" ||
        payload.role === "supervisor" ||
        payload.role === "follow_up" ||
        payload.role === "trainee") &&
      String(lead.assignedTo) !== String(payload.id) &&
      !(payload.role === "trainee" && lead.status === "sales")
    ) {
      return NextResponse.json(
        { message: "You can only edit leads assigned to you" },
        { status: 403 },
      );
    }

    // Effective status: fall back to the lead's current status if the request
    // didn't send one, so we never misjudge whether this is a "call-back" edit.
    const effectiveStatus = status ?? lead.status;

    if (effectiveStatus === "call-back") {
      if (!callbackDate) {
        return NextResponse.json(
          { message: "Callback date is required." },
          { status: 400 },
        );
      }

      const selectedDate = new Date(callbackDate + "T00:00:00");

      if (isNaN(selectedDate.getTime())) {
        return NextResponse.json(
          { message: "Invalid callback date." },
          { status: 400 },
        );
      }
    }

    const now = new Date();
    const changes: string[] = [];

    // For telecallers, phone is read-only but name is editable
    const finalPhone =
      payload.role === "telecaller" ||
      payload.role === "employee" ||
      payload.role === "meeting" ||
      payload.role === "wtc" ||
      payload.role === "wm" ||
      payload.role === "supervisor" ||
      payload.role === "follow_up" ||
      payload.role === "trainee"
        ? lead.phone
        : phone;

    // Track changes
    if (lead.name !== name) changes.push(`Name: "${lead.name}" → "${name}"`);
    if ((lead.phone || "") !== (finalPhone || ""))
      changes.push(
        `Phone: "${lead.phone || "N/A"}" → "${finalPhone || "N/A"}"`,
      );
    if ((lead.email || "") !== ((email || "").trim()))
      changes.push(
        `Email: "${lead.email || "N/A"}" → "${(email || "").trim() || "N/A"}"`,
      );
    if ((lead.country || "") !== (country || ""))
      changes.push(
        `Country: "${lead.country || "N/A"}" → "${
          country || "N/A"
        }"`,
      );
    if ((lead.state || "") !== (state || ""))
      changes.push(`State: "${lead.state || "N/A"}" → "${state || "N/A"}"`);
    if ((lead.city || "") !== (city || ""))
      changes.push(`City: "${lead.city || "N/A"}" → "${city || "N/A"}"`);

    const oldAge = lead.age ? String(lead.age) : "";
    const newAge = age ? String(age) : "";
    if (oldAge !== newAge)
      changes.push(`Age: "${oldAge || "N/A"}" → "${newAge || "N/A"}"`);

    if ((lead.status || "") !== (effectiveStatus || ""))
      changes.push(
        `Status: "${lead.status || "N/A"}" → "${effectiveStatus || "N/A"}"`,
      );

    if ((lead.passportType || "") !== (passportType || ""))
      changes.push(
        `Passport Type: "${lead.passportType || "N/A"}" → "${
          passportType || "N/A"
        }"`,
      );

    if ((lead.leadSource || "") !== (leadSource || ""))
      changes.push(
        `Lead Source: "${lead.leadSource || "N/A"}" → "${leadSource || "N/A"}"`,
      );

    if ((lead.jobApplied || "") !== (jobApplied || ""))
      changes.push(
        `Job Applied: "${lead.jobApplied || "N/A"}" → "${jobApplied || "N/A"}"`,
      );

    if ((lead.interestedCountry || "") !== (cleanInterestedCountry || ""))
      changes.push(
        `Interested Country: "${lead.interestedCountry || "N/A"}" → "${cleanInterestedCountry || "N/A"}"`,
      );

    // Format dates for comparison
    const oldDueDate = lead.dueDate
      ? new Date(lead.dueDate).toLocaleDateString("en-CA", {
          timeZone: "Asia/Kolkata",
        })
      : "";
    const newDueDate = dueDate || "";
    if (oldDueDate !== newDueDate) {
      changes.push(
        `Due Date: "${oldDueDate || "N/A"}" → "${newDueDate || "N/A"}"`,
      );
    }

    const oldCallbackDate = lead.callbackDate
      ? new Date(lead.callbackDate).toLocaleDateString("en-CA", {
          timeZone: "Asia/Kolkata",
        })
      : "";

    const newCallbackDate =
      effectiveStatus === "call-back" ? callbackDate || "" : "";

    if (oldCallbackDate !== newCallbackDate) {
      changes.push(
        `Callback Date: "${oldCallbackDate || "N/A"}" → "${
          newCallbackDate || "N/A"
        }"`,
      );
    }

    // Update the lead
    await db.collection("leads").updateOne(
      { id: leadId },
      {
        $set: {
          name: name || null,
          phone: finalPhone,
          email: email ? String(email).trim() : null,
          state: state || null,
          city: city || null,
          country: country || null,
          age: age ? parseInt(age) : null,
          passportType: passportType || null,
          leadSource: leadSource || null,
          jobApplied: jobApplied || null,
          interestedCountry: cleanInterestedCountry || null,
          status: effectiveStatus,
          ...(effectiveStatus === "call-back"
            ? {
                callbackDate: new Date(callbackDate + "T00:00:00"),
                callbackSeen: false,
              }
            : {
                callbackDate: null,
                callbackSeen: false,
              }),
          dueDate: dueDate ? new Date(dueDate + "T00:00:00") : null,
          updatedAt: now,
        },
        $push: {
          history: {
            action: "lead_updated",
            performedBy: payload.id,
            performedByName: payload.name,
            timestamp: now,
            details:
              changes.length > 0 ? changes.join("; ") : "Lead details updated",
          },
        },
      },
    );

    await logUserAction(db, {
      userId: payload.id,
      userName: payload.name,
      userRole: payload.role,
      actionType: "lead_updated",
      entityType: "lead",
      entityId: leadId,
      summary: `Updated lead #${leadId} (${lead.name || "Candidate"}): ${changes.length > 0 ? changes.slice(0, 3).join("; ") : "details updated"}`,
      metadata: { leadName: lead.name, changes },
    });

    return NextResponse.json(
      {
        message: "Lead updated successfully",
      },
      { status: 200 },
    );
  } catch (err) {
    console.error(err);
    const errorMessage = err instanceof Error ? err.message : String(err);
    return NextResponse.json(
      { message: "Server error", error: errorMessage },
      { status: 500 },
    );
  }
}