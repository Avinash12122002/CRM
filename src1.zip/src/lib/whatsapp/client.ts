/**
 * Meta WhatsApp Cloud API Client
 * Official Graph API v21.0 dispatcher with sandbox fallback and timed delay support.
 */

interface SendResult {
  success: boolean;
  messageId?: string;
  simulated?: boolean;
  error?: string;
}

export function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function getApiConfig() {
  const token = process.env.WHATSAPP_TOKEN || "";
  const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID || "";
  const isConfigured = Boolean(token && phoneNumberId);

  return { token, phoneNumberId, isConfigured };
}

interface DispatchOptions {
  skipLog?: boolean;
  sender?: "bot" | "admin";
  senderName?: string;
}

/**
 * Dispatch raw payload to Meta WhatsApp Cloud API
 */
async function sendMetaRequest(
  payload: Record<string, unknown>,
  options?: DispatchOptions
): Promise<SendResult> {
  const { token, phoneNumberId, isConfigured } = getApiConfig();

  if (!isConfigured) {
    console.log("[WhatsApp Mock Dispatch]", JSON.stringify(payload, null, 2));
    return {
      success: true,
      simulated: true,
      messageId: `sim_${Date.now()}`,
    };
  }

  try {
    const url = `https://graph.facebook.com/v21.0/${phoneNumberId}/messages`;
    const res = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    if (!res.ok) {
      console.error("[WhatsApp Meta API Error]", data);
      return { success: false, error: data?.error?.message || "Failed to send message" };
    }

    const messageId = data?.messages?.[0]?.id;

    // Asynchronously log to unified whatsapp_messages collection (unless caller handles logging)
    if (!options?.skipLog) {
      (async () => {
        try {
          const { connectToDatabase } = await import("@/lib/mongodb");
          const { logWhatsAppMessage } = await import("./messageLogger");
          const { db } = await connectToDatabase();
          const to = String(payload.to || "");
          const type = String(payload.type || "text");
          let text = "";
          let buttons: Array<{ id: string; title: string }> | undefined;
          let mediaUrl: string | undefined;

          if (type === "text") {
            text = (payload.text as any)?.body || "";
          } else if (type === "interactive") {
            const interactive = payload.interactive as any;
            text = interactive?.body?.text || "";
            if (interactive?.action?.buttons) {
              buttons = interactive.action.buttons.map((b: any) => ({
                id: b.reply?.id,
                title: b.reply?.title,
              }));
            }
          } else if (type === "video") {
            mediaUrl = (payload.video as any)?.link;
            text = (payload.video as any)?.caption || `[Video] ${mediaUrl}`;
          }

          // Use fallback label for video/list messages that have no body text,
          // so they are still logged instead of silently dropped
          const logText = text || (type === "video" ? `[Video] ${mediaUrl || ""}` : type === "interactive" ? "[Interactive List / Button Message]" : "");

          if (to && logText) {
            await logWhatsAppMessage({
              db,
              phone: to,
              sender: options?.sender || "bot",
              senderName: options?.senderName,
              text: logText,
              msgType: type as any,
              buttons,
              mediaUrl,
              messageId,
            });
          }
        } catch (_logErr) {
          // Silent error so message delivery is unaffected
        }
      })();
    }

    return { success: true, messageId };
  } catch (err) {
    console.error("[WhatsApp Network Error]", err);
    return { success: false, error: String(err) };
  }
}

/**
 * Send standard plain-text message
 */
export async function sendTextMessage(
  to: string,
  text: string,
  options?: DispatchOptions
): Promise<SendResult> {
  return sendMetaRequest(
    {
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "text",
      text: {
        body: text,
        preview_url: true,
      },
    },
    options
  );
}

/**
 * Send interactive quick-reply buttons (Max 3 buttons supported by Meta)
 */
export async function sendQuickReplyButtons(
  to: string,
  bodyText: string,
  buttons: Array<{ id: string; title: string }>,
  options?: DispatchOptions
): Promise<SendResult> {
  if (!buttons || buttons.length === 0) {
    return sendTextMessage(to, bodyText, options);
  }

  const metaButtons = buttons.slice(0, 3).map((btn) => ({
    type: "reply",
    reply: {
      id: btn.id.slice(0, 256),
      title: btn.title.slice(0, 20), // Meta limit 20 characters
    },
  }));

  return sendMetaRequest(
    {
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "interactive",
      interactive: {
        type: "button",
        body: { text: bodyText.slice(0, 1024) },
        action: { buttons: metaButtons },
      },
    },
    options
  );
}

/**
 * Send video message with an optional caption
 */
export async function sendVideoMessage(
  to: string,
  videoUrl: string,
  caption?: string,
  options?: DispatchOptions
): Promise<SendResult> {
  return sendMetaRequest(
    {
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "video",
      video: {
        link: videoUrl,
        caption: caption || undefined,
      },
    },
    options
  );
}

/**
 * Send interactive list message (e.g. for choosing available slots or days)
 */
export async function sendInteractiveList(
  to: string,
  headerText: string,
  bodyText: string,
  buttonLabel: string,
  sections: Array<{
    title: string;
    rows: Array<{ id: string; title: string; description?: string }>;
  }>,
  options?: DispatchOptions
): Promise<SendResult> {
  let totalRows = 0;
  const sanitizedSections = sections
    .map((sec) => {
      const remainingQuota = Math.max(0, 10 - totalRows);
      const rows = (sec.rows || []).slice(0, remainingQuota).map((r) => ({
        id: r.id.slice(0, 200),
        title: r.title.slice(0, 24),
        description: r.description ? r.description.slice(0, 72) : undefined,
      }));
      totalRows += rows.length;
      return {
        title: (sec.title || "Options").slice(0, 24),
        rows,
      };
    })
    .filter((sec) => sec.rows.length > 0);

  if (sanitizedSections.length === 0 || totalRows === 0) {
    return sendTextMessage(to, `${headerText ? `*${headerText}*\n\n` : ""}${bodyText}`, options);
  }

  return sendMetaRequest(
    {
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "interactive",
      interactive: {
        type: "list",
        header: { type: "text", text: headerText.slice(0, 60) },
        body: { text: bodyText.slice(0, 1024) },
        action: {
          button: buttonLabel.slice(0, 20),
          sections: sanitizedSections,
        },
      },
    },
    options
  );
}
